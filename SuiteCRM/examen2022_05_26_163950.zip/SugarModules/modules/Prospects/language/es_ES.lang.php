<?php 
 // created: 2022-05-26 16:39:48
$mod_strings['LBL_DESCRIPCION'] = 'Descripcion';

?>
