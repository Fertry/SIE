<?php
 // created: 2022-04-26 09:13:43
$dictionary['Prospect']['fields']['jjwg_maps_geocode_status_c']['inline_edit']=1;

 ?>