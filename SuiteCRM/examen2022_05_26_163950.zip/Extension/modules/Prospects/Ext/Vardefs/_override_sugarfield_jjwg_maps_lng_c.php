<?php
 // created: 2022-04-26 09:13:43
$dictionary['Prospect']['fields']['jjwg_maps_lng_c']['inline_edit']=1;

 ?>