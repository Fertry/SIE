<?php
 // created: 2022-05-26 16:37:41
$dictionary['Prospect']['fields']['descripcion_c']['inline_edit']='1';
$dictionary['Prospect']['fields']['descripcion_c']['labelValue']='Descripcion';

 ?>